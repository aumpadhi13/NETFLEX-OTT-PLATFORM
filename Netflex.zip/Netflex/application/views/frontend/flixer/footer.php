<footer>
	<div class="row">
		<div class="col-lg-12">
			<ul class="list-unstyled">
				<li><a href="<?php echo base_url();?>index.php?general/faq"><?php echo get_phrase('Faq');?></a></li>
				<li><a href="<?php echo base_url();?>index.php?general/privacypolicy"><?php echo get_phrase('Privacy_Policy');?></a></li>
				<li><a href="<?php echo base_url();?>index.php?general/refundpolicy"><?php echo get_phrase('Refund_Policy');?></a></li>
				<li><a href="<?php echo base_url();?>index.php?home/signin/admin"><?php echo get_phrase('admin');?></a></li>
			</ul>
			<p>Made by <a href="http://creativeitem.com/" rel="nofollow">Creativeitem</a>. <a href="http://support.creativeitem.com/" target="_blank">Get support</a>.</p>
		</div>
	</div>
</footer>
